export const products = [
  {
    id: '1',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/yBd217BB/jacket.png' }
  },
  {
    id: '2',
    title: 'Feature Product Title',
    price: '$499.00',
   image: { uri: 'https://i.ibb.co/8DG5RjGM/blueshirt.png' },
  },
  {
    id: '3',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/QjX71HGT/halfbluehalfwhite.png' },
  },
  {
    id: '4',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/Rpt4RVK5/056865bdbe984b50c1e66fae7d80675051376bed.png' },
  },
  {
    id: '5',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/604P46F1/3d7d3fe714f0f68c4de49f262a157a27376f8b8d.png' },
  },
  {
    id: '6',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/WN1bLfZd/adfb56045e107329c053e79c8b1ab8fa091df2fd.png' },
  },
  {
    id: '7',
    title: 'blue shirt',
    price: '$459.00',
    image: { uri: 'https://i.ibb.co/wrzK706r/c65978fc25bf783d9597192032a4e9d3e1fd24cb.png' },
  },
  {
    id: '8',
    title: 'Feature Product Title',
    price: '$499.00',
    image: { uri: 'https://i.ibb.co/8D0dBpB5/32d357eb1c590e9d78224b0a81a3fa43852d0795.png' },
  },
];